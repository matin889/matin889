<?php
//skapa koppling till databasen
$dbhost = "localhost";
$dbuser = "root";
$dbpass = "";
$dbname = "Data";

if(!$con = mysqli_connect($dbhost,$dbuser,$dbpass,$dbname))
{

	die("failed to connect!");
}
