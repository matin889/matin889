<?php 

session_start();

	include("connection.php");
	include("functions.php");


	if($_SERVER['REQUEST_METHOD'] == "POST")
	{
		//escape specialtecken, om något publiceras på inloggningssidan
		$user_name = mysqli_real_escape_string($con, $_POST['user_name']);
		$password = mysqli_real_escape_string($con, $_POST['password']);
        
		// validering av inmatade data
		if(!empty($user_name) && !empty($password) && !is_numeric($user_name))
		{

			//läsa data från databasen
			$query = "select * from users where user_name = '$user_name' limit 1";
			$result = mysqli_query($con, $query);

			if($result)
			{
				if($result && mysqli_num_rows($result) > 0)
				{

					$user_data = mysqli_fetch_assoc($result);
					
					if($user_data['password'] === $password)
					//if(password_verify($password, $hashed_password, $user_data['password']))
					{

						$_SESSION['user_id'] = $user_data['user_id'];
						//omdirigera till hemsidan
						header("Location: index.php");
						die;
					}
				}
			}
			
			echo "Fel användarnamn eller lösenord! Om du inte är registrerad ännu, vänligen registrera dig först för att besöka sidan!";
		}else
		{
			echo "Fel användarnamn eller lösenord! Om du inte är registrerad ännu, vänligen registrera dig först för att besöka sidan!";
		}
	}

?>


<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
</head>
<body>

	<style type="text/css">
	
	#text{

		height: 25px;
		border-radius: 5px;
		padding: 4px;
		border: solid thin #aaa;
		width: 100%;
	}

	#button{

		padding: 10px;
		width: 100px;
		color: white;
		background-color: lightblue;
		border: none;
	}

	#box{

		background-color: grey;
		margin: auto;
		width: 300px;
		padding: 20px;
	}

	</style>

	<div id="box">
		
		<form method="post">
			<div style="font-size: 20px;margin: 10px;color: white;">Login</div>

			<input id="text" type="text" name="user_name" placeholder="Username"><br><br>
			<input id="text" type="password" name="password" placeholder="password"><br><br>

			<input id="button" type="submit" value="Login"><br><br>

			<a href="signup.php">Click to Signup</a><br><br>
		</form>
	</div>
</body>
</html>