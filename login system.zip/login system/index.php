<?php 
session_start();
	$_SESSION;

	include("connection.php");
	include("functions.php");

	$user_data = check_login($con);

?>

<!DOCTYPE html>
<html lang="sv">
<head>
	<meta charset="UTF-8"> 
	<title>Min webbsida</title>
</head>
<body>

	<a href="logout.php">Logout</a>
	<h1>Välkommen till min webbsida</h1>

	<br>
	Hej!, <?php echo $user_data['user_name']; ?>
</body>
</html>